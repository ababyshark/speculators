#!/bin/bash
set -euo pipefail
export ASCEND_RT_VISIBLE_DEVICES=8,9,10,11,12,13,14,15
export HCCL_CONNECT_TIMEOUT=3600 HCCL_BUFFSIZE=200
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export TOKENIZERS_PARALLELISM=false
export PATH=/data1/mtp_training/venv/bin:$PATH
export PYTHONPATH=/workspace/speculators/src:/workspace/speculators/hs_connectors/src:${PYTHONPATH:-}
LOG=/data1/mtp_training/runs/glm53_mtp_formal100_8k/baseline_mtp_service.log
exec >>"$LOG" 2>&1
echo "[$(date -Is)] starting step0 MTP service"
exec /data1/mtp_training/venv/bin/python -m vllm.entrypoints.cli.main serve \
  /data1/weight/GLM-5.3-w4a8-spec \
  --speculative_config '{"method":"mtp","num_speculative_tokens":1}' \
  --tensor-parallel-size 8 \
  --port 8010 \
  --host 0.0.0.0 \
  --served-model-name glm53-mtp-step0 \
  --max-num-seqs 2 \
  --max-model-len 2048 \
  --max-num-batched-tokens 2048 \
  --trust-remote-code \
  --gpu-memory-utilization 0.98 \
  --quantization ascend \
  --kv-cache-dtype auto \
  --no-enable-prefix-caching \
  --enforce-eager

