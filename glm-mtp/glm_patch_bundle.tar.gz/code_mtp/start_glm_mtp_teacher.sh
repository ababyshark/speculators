#!/bin/bash
set -euo pipefail
MODEL=/data1/weight/GLM-5.3-w4a8-spec
RUN_DIR=/data1/mtp_training/teacher
export ASCEND_RT_VISIBLE_DEVICES=0,1,2,3,4,5,6,7
export PYTHONPATH="/workspace/code_mtp:/workspace/code2:${PYTHONPATH:-}"
export PATH="/data1/mtp_training/venv/bin:$PATH"
export HCCL_BUFFSIZE=200 HCCL_CONNECT_TIMEOUT=3600
export LCCL_DETERMINISTIC=1 HCCL_DETERMINISTIC=true
export ATB_MATMUL_SHUFFLE_K_ENABLE=0 ATB_LLM_LCOC_ENABLE=0
export HCCL_OP_EXPANSION_MODE=AIV
export PYTORCH_NPU_ALLOC_CONF=expandable_segments:True
export TOKENIZERS_PARALLELISM=false
mkdir -p "$RUN_DIR/hidden_states"
cd /workspace/speculators
exec python scripts/launch_vllm.py train "$MODEL" \
  --target-layer-ids 78 \
  --hidden-states-path "$RUN_DIR/hidden_states" \
  --provenance-dir "$RUN_DIR/provenance_$(date +%Y%m%d_%H%M%S)" \
  --no-hash-checkpoints -- \
  --host 0.0.0.0 --port 8000 \
  --api-server-count 1 --renderer-num-workers 1 \
  --tensor-parallel-size 8 --data-parallel-size 1 \
  --worker-extension-cls glm_mtp_teacher_extension.GLMMTPTeacher \
  --enable-expert-parallel --seed 1024 \
  --served-model-name "$MODEL" \
  --max-num-seqs 2 --max-model-len 8193 --max-num-batched-tokens 4096 \
  --trust-remote-code --gpu-memory-utilization 0.90 \
  --quantization ascend --kv-cache-dtype auto \
  --attention_config.indexer_kv_dtype int8 \
  --no-enable-prefix-caching --enforce-eager
